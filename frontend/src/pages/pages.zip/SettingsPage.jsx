import React, { useState, useEffect } from 'react';
import { useToast } from '../components/Toast';
import { api } from '../api';
import { User, Lock, Key, Webhook, Calendar, Palette, Save, Trash2, Plus, Eye, EyeOff } from 'lucide-react';

const TABS = [
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'password', label: 'Password', icon: Lock },
  { id: 'api-keys', label: 'API Keys', icon: Key },
  { id: 'webhooks', label: 'Webhooks', icon: Webhook },
  { id: 'scheduled', label: 'Scheduled', icon: Calendar },
  { id: 'whitelabel', label: 'White Label', icon: Palette },
];

export default function SettingsPage() {
  const [tab, setTab] = useState('profile');
  const [user, setUser] = useState(null);
  const { addToast } = useToast();

  useEffect(() => {
    const stored = localStorage.getItem('user');
    if (stored) setUser(JSON.parse(stored));
  }, []);

  return (
    <div style={{ maxWidth: 900, margin: '0 auto', padding: '24px 0' }}>
      <h1 style={{ fontSize: 24, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 24 }}>Settings</h1>
      <div style={{ display: 'flex', gap: 24 }}>
        <div style={{ width: 200, flexShrink: 0 }}>
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '10px 12px', background: tab === t.id ? 'var(--accent)' : 'transparent', color: tab === t.id ? '#fff' : 'var(--text-secondary)', border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 13, marginBottom: 4, textAlign: 'left' }}>
              <t.icon size={15} /> {t.label}
            </button>
          ))}
        </div>
        <div style={{ flex: 1 }}>
          {tab === 'profile' && <ProfileTab user={user} setUser={setUser} addToast={addToast} />}
          {tab === 'password' && <PasswordTab addToast={addToast} />}
          {tab === 'api-keys' && <ApiKeysTab addToast={addToast} />}
          {tab === 'webhooks' && <WebhooksTab addToast={addToast} />}
          {tab === 'scheduled' && <ScheduledTab addToast={addToast} />}
          {tab === 'whitelabel' && <WhiteLabelTab addToast={addToast} />}
        </div>
      </div>
    </div>
  );
}

function ProfileTab({ user, setUser, addToast }) {
  const [username, setUsername] = useState(user?.username || '');
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    try {
      const data = await api.updateMe({ username });
      setUser(data);
      localStorage.setItem('user', JSON.stringify(data));
      addToast('Profile updated', 'success');
    } catch (err) {
      addToast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ background: 'var(--bg-secondary)', borderRadius: 12, padding: 24, border: '1px solid var(--border)' }}>
      <h2 style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 20 }}>Profile</h2>
      <div style={{ marginBottom: 16 }}>
        <label style={{ display: 'block', fontSize: 13, color: 'var(--text-secondary)', marginBottom: 6 }}>Email</label>
        <input value={user?.email || ''} disabled
          style={{ width: '100%', padding: '10px 12px', background: 'var(--bg-primary)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--text-secondary)', fontSize: 14, opacity: 0.6 }} />
      </div>
      <div style={{ marginBottom: 20 }}>
        <label style={{ display: 'block', fontSize: 13, color: 'var(--text-secondary)', marginBottom: 6 }}>Username</label>
        <input value={username} onChange={e => setUsername(e.target.value)}
          style={{ width: '100%', padding: '10px 12px', background: 'var(--bg-primary)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--text-primary)', fontSize: 14, boxSizing: 'border-box' }} />
      </div>
      <div style={{ marginBottom: 16 }}>
        <label style={{ display: 'block', fontSize: 13, color: 'var(--text-secondary)', marginBottom: 6 }}>Role</label>
        <span style={{ padding: '4px 12px', background: 'var(--accent-bg)', color: 'var(--accent)', borderRadius: 6, fontSize: 13 }}>{user?.role || 'VIEWER'}</span>
      </div>
      <button className="btn btn-primary" onClick={save} disabled={saving} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <Save size={14} /> {saving ? 'Saving...' : 'Save Changes'}
      </button>
    </div>
  );
}

function PasswordTab({ addToast }) {
  const [current, setCurrent] = useState('');
  const [newPass, setNewPass] = useState('');
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    try {
      await api.changePassword(current, newPass);
      addToast('Password changed', 'success');
      setCurrent('');
      setNewPass('');
    } catch (err) {
      addToast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ background: 'var(--bg-secondary)', borderRadius: 12, padding: 24, border: '1px solid var(--border)' }}>
      <h2 style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 20 }}>Change Password</h2>
      <div style={{ marginBottom: 16 }}>
        <label style={{ display: 'block', fontSize: 13, color: 'var(--text-secondary)', marginBottom: 6 }}>Current Password</label>
        <input type="password" value={current} onChange={e => setCurrent(e.target.value)}
          style={{ width: '100%', padding: '10px 12px', background: 'var(--bg-primary)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--text-primary)', fontSize: 14, boxSizing: 'border-box' }} />
      </div>
      <div style={{ marginBottom: 20 }}>
        <label style={{ display: 'block', fontSize: 13, color: 'var(--text-secondary)', marginBottom: 6 }}>New Password</label>
        <input type="password" value={newPass} onChange={e => setNewPass(e.target.value)} minLength={8}
          style={{ width: '100%', padding: '10px 12px', background: 'var(--bg-primary)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--text-primary)', fontSize: 14, boxSizing: 'border-box' }} />
      </div>
      <button className="btn btn-primary" onClick={save} disabled={saving} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <Lock size={14} /> {saving ? 'Saving...' : 'Change Password'}
      </button>
    </div>
  );
}

function ApiKeysTab({ addToast }) {
  const [keys, setKeys] = useState([]);
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try { setKeys(await api.listApiKeys()); } catch (e) { addToast(e.message, 'error'); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const create = async () => {
    try {
      await api.createApiKey(name || 'API Key');
      setName('');
      addToast('API key created', 'success');
      load();
    } catch (e) { addToast(e.message, 'error'); }
  };

  const revoke = async (id) => {
    try {
      await api.revokeApiKey(id);
      addToast('API key revoked', 'success');
      load();
    } catch (e) { addToast(e.message, 'error'); }
  };

  return (
    <div style={{ background: 'var(--bg-secondary)', borderRadius: 12, padding: 24, border: '1px solid var(--border)' }}>
      <h2 style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 20 }}>API Keys</h2>
      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        <input value={name} onChange={e => setName(e.target.value)} placeholder="Key name"
          style={{ flex: 1, padding: '10px 12px', background: 'var(--bg-primary)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--text-primary)', fontSize: 14 }} />
        <button className="btn btn-primary btn-sm" onClick={create} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <Plus size={13} /> Create
        </button>
      </div>
      {loading ? <p style={{ color: 'var(--text-secondary)' }}>Loading...</p> : keys.length === 0 ? (
        <p style={{ color: 'var(--text-secondary)', fontSize: 13 }}>No API keys yet</p>
      ) : keys.map(k => (
        <div key={k.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
          <div>
            <div style={{ fontSize: 14, color: 'var(--text-primary)' }}>{k.name}</div>
            <div style={{ fontSize: 12, color: 'var(--text-secondary)', fontFamily: 'monospace' }}>{k.key}</div>
            <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>Created: {k.created_at?.split('T')[0]}</div>
          </div>
          <button className="btn btn-outline btn-sm" onClick={() => revoke(k.id)} style={{ color: '#ef4444' }}>
            <Trash2 size={13} /> Revoke
          </button>
        </div>
      ))}
    </div>
  );
}

function WebhooksTab({ addToast }) {
  const [hooks, setHooks] = useState([]);
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try { setHooks(await api.listWebhooks()); } catch (e) { addToast(e.message, 'error'); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const create = async () => {
    try {
      await api.createWebhook(url, ['audit.completed', 'audit.failed']);
      setUrl('');
      addToast('Webhook created', 'success');
      load();
    } catch (e) { addToast(e.message, 'error'); }
  };

  const del = async (id) => {
    try { await api.deleteWebhook(id); addToast('Deleted', 'success'); load(); } catch (e) { addToast(e.message, 'error'); }
  };

  const test = async (id) => {
    try { await api.testWebhook(id, {}); addToast('Test sent', 'success'); } catch (e) { addToast(e.message, 'error'); }
  };

  return (
    <div style={{ background: 'var(--bg-secondary)', borderRadius: 12, padding: 24, border: '1px solid var(--border)' }}>
      <h2 style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 20 }}>Webhooks</h2>
      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        <input value={url} onChange={e => setUrl(e.target.value)} placeholder="https://your-webhook-url.com"
          style={{ flex: 1, padding: '10px 12px', background: 'var(--bg-primary)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--text-primary)', fontSize: 14 }} />
        <button className="btn btn-primary btn-sm" onClick={create} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <Plus size={13} /> Add
        </button>
      </div>
      {loading ? <p style={{ color: 'var(--text-secondary)' }}>Loading...</p> : hooks.length === 0 ? (
        <p style={{ color: 'var(--text-secondary)', fontSize: 13 }}>No webhooks configured</p>
      ) : hooks.map(w => (
        <div key={w.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
          <div>
            <div style={{ fontSize: 13, color: 'var(--text-primary)', fontFamily: 'monospace' }}>{w.url}</div>
            <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>Events: {w.events?.join(', ')}</div>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <button className="btn btn-outline btn-sm" onClick={() => test(w.id)}>Test</button>
            <button className="btn btn-outline btn-sm" onClick={() => del(w.id)} style={{ color: '#ef4444' }}><Trash2 size={13} /></button>
          </div>
        </div>
      ))}
    </div>
  );
}

function ScheduledTab({ addToast }) {
  const [items, setItems] = useState([]);
  const [url, setUrl] = useState('');
  const [freq, setFreq] = useState('weekly');
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try { setItems(await api.listScheduled()); } catch (e) { addToast(e.message, 'error'); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const create = async () => {
    try {
      await api.createScheduled({ website_url: url, frequency: freq });
      setUrl('');
      addToast('Scheduled audit created', 'success');
      load();
    } catch (e) { addToast(e.message, 'error'); }
  };

  const del = async (id) => {
    try { await api.deleteScheduled(id); addToast('Deleted', 'success'); load(); } catch (e) { addToast(e.message, 'error'); }
  };

  return (
    <div style={{ background: 'var(--bg-secondary)', borderRadius: 12, padding: 24, border: '1px solid var(--border)' }}>
      <h2 style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 20 }}>Scheduled Audits</h2>
      <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
        <input value={url} onChange={e => setUrl(e.target.value)} placeholder="https://example.com"
          style={{ flex: 1, padding: '10px 12px', background: 'var(--bg-primary)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--text-primary)', fontSize: 14 }} />
        <select value={freq} onChange={e => setFreq(e.target.value)}
          style={{ padding: '10px 12px', background: 'var(--bg-primary)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--text-primary)', fontSize: 14 }}>
          <option value="daily">Daily</option>
          <option value="weekly">Weekly</option>
          <option value="monthly">Monthly</option>
        </select>
        <button className="btn btn-primary btn-sm" onClick={create} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <Plus size={13} /> Schedule
        </button>
      </div>
      {loading ? <p style={{ color: 'var(--text-secondary)' }}>Loading...</p> : items.length === 0 ? (
        <p style={{ color: 'var(--text-secondary)', fontSize: 13 }}>No scheduled audits</p>
      ) : items.map(s => (
        <div key={s.id} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
          <div>
            <div style={{ fontSize: 13, color: 'var(--text-primary)' }}>{s.website_url}</div>
            <div style={{ fontSize: 11, color: 'var(--text-secondary)' }}>Every {s.frequency} | Next: {s.next_run?.split('T')[0]}</div>
          </div>
          <button className="btn btn-outline btn-sm" onClick={() => del(s.id)} style={{ color: '#ef4444' }}><Trash2 size={13} /></button>
        </div>
      ))}
    </div>
  );
}

function WhiteLabelTab({ addToast }) {
  const [settings, setSettings] = useState({ company_name: '', logo_url: '', primary_color: '#3B82F6', secondary_color: '#1E293B', custom_domain: '', is_active: false });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    try { const data = await api.getWhiteLabel(); setSettings(data); } catch (e) { addToast(e.message, 'error'); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const save = async () => {
    setSaving(true);
    try { await api.updateWhiteLabel(settings); addToast('Settings saved', 'success'); } catch (e) { addToast(e.message, 'error'); }
    setSaving(false);
  };

  const update = (key, val) => setSettings(prev => ({ ...prev, [key]: val }));

  return (
    <div style={{ background: 'var(--bg-secondary)', borderRadius: 12, padding: 24, border: '1px solid var(--border)' }}>
      <h2 style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 20 }}>White Label Settings</h2>
      {loading ? <p style={{ color: 'var(--text-secondary)' }}>Loading...</p> : (
        <>
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 13, color: 'var(--text-secondary)', marginBottom: 6 }}>Company Name</label>
            <input value={settings.company_name} onChange={e => update('company_name', e.target.value)}
              style={{ width: '100%', padding: '10px 12px', background: 'var(--bg-primary)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--text-primary)', fontSize: 14, boxSizing: 'border-box' }} />
          </div>
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 13, color: 'var(--text-secondary)', marginBottom: 6 }}>Logo URL</label>
            <input value={settings.logo_url} onChange={e => update('logo_url', e.target.value)}
              style={{ width: '100%', padding: '10px 12px', background: 'var(--bg-primary)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--text-primary)', fontSize: 14, boxSizing: 'border-box' }} />
          </div>
          <div style={{ display: 'flex', gap: 16, marginBottom: 16 }}>
            <div style={{ flex: 1 }}>
              <label style={{ display: 'block', fontSize: 13, color: 'var(--text-secondary)', marginBottom: 6 }}>Primary Color</label>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <input type="color" value={settings.primary_color} onChange={e => update('primary_color', e.target.value)} style={{ width: 40, height: 36, border: 'none', cursor: 'pointer' }} />
                <input value={settings.primary_color} onChange={e => update('primary_color', e.target.value)}
                  style={{ flex: 1, padding: '10px 12px', background: 'var(--bg-primary)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--text-primary)', fontSize: 14 }} />
              </div>
            </div>
            <div style={{ flex: 1 }}>
              <label style={{ display: 'block', fontSize: 13, color: 'var(--text-secondary)', marginBottom: 6 }}>Secondary Color</label>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <input type="color" value={settings.secondary_color} onChange={e => update('secondary_color', e.target.value)} style={{ width: 40, height: 36, border: 'none', cursor: 'pointer' }} />
                <input value={settings.secondary_color} onChange={e => update('secondary_color', e.target.value)}
                  style={{ flex: 1, padding: '10px 12px', background: 'var(--bg-primary)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--text-primary)', fontSize: 14 }} />
              </div>
            </div>
          </div>
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 13, color: 'var(--text-secondary)', marginBottom: 6 }}>Custom Domain</label>
            <input value={settings.custom_domain} onChange={e => update('custom_domain', e.target.value)} placeholder="seo.yourdomain.com"
              style={{ width: '100%', padding: '10px 12px', background: 'var(--bg-primary)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--text-primary)', fontSize: 14, boxSizing: 'border-box' }} />
          </div>
          <div style={{ marginBottom: 20, display: 'flex', alignItems: 'center', gap: 8 }}>
            <input type="checkbox" checked={settings.is_active} onChange={e => update('is_active', e.target.checked)} style={{ width: 16, height: 16 }} />
            <label style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Enable White Label</label>
          </div>
          <button className="btn btn-primary" onClick={save} disabled={saving} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <Save size={14} /> {saving ? 'Saving...' : 'Save Settings'}
          </button>
        </>
      )}
    </div>
  );
}
